import React, { Component } from "react";
import "./Contact.css";
import { Container, Row, Col } from "reactstrap";
import AOS from "aos";
import axios from "axios";
import Icofont from "react-icofont";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

class Contact extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      comapany: "",
      email: "",
      description: "",
      interested: "UI/UX Design",
    };
  }

  componentDidMount() {
    document.title = "Contact | Moisture";
    AOS.init({
      disable: "mobile", // accepts following values: 'phone', 'tablet', 'mobile', boolean, expression or function
      delay: 500,
      duration: 1000,
    });
  }
  onSubmit = () => {
    axios
      .post(
        "https://moisturestudio.com/moisturestudioAdmin/api/client/inquiry",
        {
          name: this.state.name,
          email: this.state.email,
          company: this.state.comapany,
          interested_in: this.state.interested,
          project_description: this.state.description,
          type: "",
          files: this.state.files,
        }
      )
      .then(function (response) {
        // console.log(response);
        toast.success(response.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      })
      .catch(function (error) {
        // console.log(error);
        toast.error("validation fail", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      });
  };
  onChangeName = (e) => {
    this.setState({ name: e.target.value });
  };
  onChangeEmail = (e) => {
    this.setState({ email: e.target.value });
  };
  onChnageCompany = (e) => {
    this.setState({ comapany: e.target.value });
  };
  onchangeDescription = (e) => {
    this.setState({ description: e.target.value });
  };

  onclickInterested = (data) => {
    console.log(data);
    // this.setState({ interested: data });
  };

  _handleImageChange(e) {
    e.preventDefault();

    let reader = new FileReader();
    let file = e.target.files[0];

    reader.onloadend = () => {
      this.setState({
        files: reader.result,
      });
    };

    reader.readAsDataURL(file);
  }

  render() {
    return (
      <>
        <div className="main-area fix">
          <Container>
            <ToastContainer
              position="top-right"
              autoClose={5000}
              hideProgressBar={false}
              newestOnTop={false}
              closeOnClick
              rtl={false}
              pauseOnFocusLoss
              draggable
              pauseOnHover
            />
            {/* Same as */}
            <ToastContainer />

            <Row>
              <div className="hero-area about-pge">
                <div className="hero-content-wrapper">
                  <div className="hero-content-innner-wrapper style-2 style-3 text-center">
                    <div className="lineup-wrapper11">
                      <h1 data-aos="fade-right">
                        <img
                          src={"images/Contact-header.svg"}
                          alt=""
                          className="aboutbanner banner aos-init aos-animate"
                        />
                      </h1>
                    </div>
                    <h2 data-aos="fade-up">
                      We're <span className="text-purple">talkative</span>,
                      <br />
                      So let's start <span className="text-pink">talk</span>
                    </h2>
                  </div>
                </div>
              </div>
            </Row>
          </Container>
        </div>
        <section id="servicescontactus">
          <Container>
            <div className="service-two-area">
              <h3 className="sec-title">Our Offices</h3>
              <div className="service-two-flex-wrappernew">
                <Row>
                  <Col md="12">
                    <Col md="6">
                      <div className="contact-two-item" data-aos="fade-up">
                        <h4 className="text-purple contact">India</h4>
                        <ul className="contact-two-list">
                          <li>D/208 Tatvam Arcade, Near Jilla Seva Sadan,</li>
                          <li>Modasa, Arvalli - 383315</li>
                          <li>India</li>
                        </ul>
                      </div>
                    </Col>
                    <Col md="4">
                      <div className="contact-two-item" data-aos="fade-up">
                        <h4 className="text-purple contact">Spain</h4>
                        <ul className="contact-two-list">
                          <li>Carrer dels Ferrocarrils Catalans 4 - 3</li>
                          <li> 99 08038 Barcelona</li>
                          <li>Spain</li>
                        </ul>
                      </div>
                    </Col>
                    <Col md="2">
                    </Col>
                  </Col>
                </Row>
              </div>
            </div>
          </Container>
        </section>
        <section id="clientareacontacts">
          <Container>
            <Row>
              <div className="client-area">
                <h3 className="sec-title formtitle">Let's Start discussion</h3>
                <div className="dropdown">
                  <button type="button" className="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                    New Projects
                  </button>
                  <div className="dropdown-menu">
                    <a className="dropdown-item" href="#">New Projects</a>
                    <a className="dropdown-item" href="#">Career</a>
                  </div>
                </div>
                <br />
                <div className="form">
                  <div className="input-inside">
                    <label for="">What's your full name?</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder=""
                      value={this.state.name}
                      onChange={this.onChangeName}
                    />
                  </div>
                  <div className="input-inside">
                    <label for="">Company</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder=""
                      value={this.state.comapany}
                      onChange={this.onChnageCompany}
                    />
                  </div>
                  <div className="input-inside">
                    <label for="">Email</label>
                    <input
                      type="email"
                      className="form-control"
                      placeholder=""
                      value={this.state.email}
                      onChange={this.onChangeEmail}
                    />
                  </div>
                  <div className="input-inside passion">
                    <label for="">Interested in</label>
                    <div className="intersting-sub-wrapper">
                      <button
                        onClick={this.onclickInterested("UI/UX Design")}
                        className={
                          this.state.interested == "UI/UX Design"
                            ? "active"
                            : ""
                        }
                      >
                        UI/UX Design
                      </button>
                      <button
                        onClick={this.onclickInterested("Development")}
                        className={
                          this.state.interested == "Development" ? "active" : ""
                        }
                      >
                        Development
                      </button>
                      <button
                        onClick={this.onclickInterested("Website")}
                        className={
                          this.state.interested == "Website" ? "active" : ""
                        }
                      >
                        Website
                      </button>
                      <button
                        onClick={this.onclickInterested("App")}
                        className={
                          this.state.interested == "App" ? "active" : ""
                        }
                      >
                        App
                      </button>
                      <button
                        onClick={this.onclickInterested("Marketing")}
                        className={
                          this.state.interested == "Marketing" ? "active" : ""
                        }
                      >
                        Marketing
                      </button>
                      <button
                        onClick={this.onclickInterested("AI/ML")}
                        className={
                          this.state.interested == "AI/ML" ? "active" : ""
                        }
                      >
                        AI/ML
                      </button>
                      <button
                        onClick={this.onclickInterested("Other")}
                        className={
                          this.state.interested == "Other" ? "active" : ""
                        }
                      >
                        Other
                      </button>
                    </div>
                  </div>
                  <div className="input-inside with-textarea">
                    <div className="tw-flex-wrapper d-flex justify-content-between">
                      <label for="">Project description</label>
                      <label className="upload-des">
                        <input
                          type="file"
                          accept=".pdf,.doc,.jpg,.png,"
                          onChange={(e) => this._handleImageChange(e)}
                        />
                        <Icofont icon="upload" title="File Uploads"></Icofont>
                      </label>
                    </div>
                    <textarea
                      className="form-control"
                      name=""
                      id=""
                      cols="30"
                      rows="10"
                      onChange={this.onchangeDescription}
                    ></textarea>
                  </div>
                  <div className="text-center mt-30">
                    <button className="btn btn-purple" onClick={this.onSubmit}>
                      Submit
                    </button>
                  </div>
                </div>
              </div>
            </Row>
          </Container>
        </section>
        <section id="needhelpmoisturestudio">
          <Container>
            <Row>
              <Col md="6">
                <div className="contact-info">
                  <h4>Need Help ? We're here</h4>
                  <p>
                    Why we are different than other ? We built product that
                    helps business to grow exponential, we built MVP that reduce
                    startup cost and help them to raise funds.
                  </p>
                  <a href="contact" className="btn btn-purple">
                    Start Something new
                  </a>
                </div>
              </Col>
              <Col md="6">
                <div className="logo">
                  <a href="/">
                    <img
                      src={"images/Big-logo.svg"}
                      alt=""
                      className="img-responsive imglogo"
                    />
                  </a>
                </div>
              </Col>
            </Row>
          </Container>
        </section>
      </>
    );
  }
}
export default Contact;
